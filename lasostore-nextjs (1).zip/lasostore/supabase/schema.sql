-- =========================================================
-- LASOSTORE - esquema + seguridad (Supabase / Postgres)
-- =========================================================

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  icon text,
  image_url text,
  active boolean not null default true
);

create table products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  category_id uuid references categories(id) on delete set null,
  price numeric(10,2) not null check (price >= 0),
  old_price numeric(10,2),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  rating numeric(2,1) default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table banners (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  image_url text,
  button_text text,
  button_url text,
  active boolean not null default true,
  position integer not null default 0
);

create table orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  total numeric(10,2) not null,
  status text not null default 'pending' check (status in ('pending','paid','shipped','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id),
  quantity integer not null check (quantity > 0),
  price numeric(10,2) not null
);

create function public.handle_new_user() returns trigger as $$
begin
  insert into public.profiles (id, email, name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.email), 'customer');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create function public.set_updated_at() returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

create trigger products_set_updated_at
  before update on products
  for each row execute procedure public.set_updated_at();

alter table profiles enable row level security;
alter table categories enable row level security;
alter table products enable row level security;
alter table banners enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

create function public.is_admin() returns boolean as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$ language sql security definer stable;

create policy "profiles: select own or admin" on profiles
  for select using (auth.uid() = id or public.is_admin());
create policy "profiles: update own (no role)" on profiles
  for update using (auth.uid() = id)
  with check (auth.uid() = id and role = (select role from profiles p where p.id = auth.uid()));
create policy "profiles: admin manages roles" on profiles
  for update using (public.is_admin());

create policy "categories: public read active" on categories
  for select using (active or public.is_admin());
create policy "categories: admin write" on categories
  for all using (public.is_admin()) with check (public.is_admin());

create policy "products: public read active" on products
  for select using (active or public.is_admin());
create policy "products: admin write" on products
  for all using (public.is_admin()) with check (public.is_admin());

create policy "banners: public read active" on banners
  for select using (active or public.is_admin());
create policy "banners: admin write" on banners
  for all using (public.is_admin()) with check (public.is_admin());

create policy "orders: select own or admin" on orders
  for select using (auth.uid() = user_id or public.is_admin());
create policy "orders: insert own" on orders
  for insert with check (auth.uid() = user_id);
create policy "orders: admin update status" on orders
  for update using (public.is_admin());

create policy "order_items: select via own order or admin" on order_items
  for select using (
    public.is_admin() or exists (select 1 from orders o where o.id = order_id and o.user_id = auth.uid())
  );
-- Sin policy de INSERT para el cliente: order_items solo se crea desde el
-- backend (service role) dentro de /api/checkout.

create function public.create_order(p_user_id uuid, p_items jsonb) returns uuid as $$
declare
  v_order_id uuid;
  v_item jsonb;
  v_price numeric(10,2);
  v_stock integer;
  v_total numeric(10,2) := 0;
begin
  insert into orders (user_id, total, status) values (p_user_id, 0, 'pending') returning id into v_order_id;

  for v_item in select * from jsonb_array_elements(p_items) loop
    select price, stock into v_price, v_stock
      from products where id = (v_item->>'product_id')::uuid and active for update;

    if v_stock is null then raise exception 'Producto no encontrado o inactivo'; end if;
    if v_stock < (v_item->>'quantity')::int then
      raise exception 'Stock insuficiente para el producto %', v_item->>'product_id';
    end if;

    update products set stock = stock - (v_item->>'quantity')::int where id = (v_item->>'product_id')::uuid;
    insert into order_items (order_id, product_id, quantity, price)
      values (v_order_id, (v_item->>'product_id')::uuid, (v_item->>'quantity')::int, v_price);
    v_total := v_total + v_price * (v_item->>'quantity')::int;
  end loop;

  update orders set total = v_total where id = v_order_id;
  return v_order_id;
end;
$$ language plpgsql security definer;
