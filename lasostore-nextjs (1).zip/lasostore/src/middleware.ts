import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

export async function middleware(req: NextRequest) {
  let res = NextResponse.next();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get: (name) => req.cookies.get(name)?.value,
        set: (name, value, options) => { res.cookies.set({ name, value, ...options }); },
        remove: (name, options) => { res.cookies.set({ name, value: "", ...options, maxAge: 0 }); }
      }
    }
  );

  const { data: { user } } = await supabase.auth.getUser();

  if (req.nextUrl.pathname.startsWith("/admin")) {
    if (!user) return NextResponse.redirect(new URL("/login?next=/admin", req.url));
    const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single();
    if (profile?.role !== "admin") return NextResponse.redirect(new URL("/", req.url));
  }

  if (req.nextUrl.pathname.startsWith("/account") && !user) {
    return NextResponse.redirect(new URL("/login?next=/account", req.url));
  }

  return res;
}

export const config = { matcher: ["/admin/:path*", "/account/:path*"] };
