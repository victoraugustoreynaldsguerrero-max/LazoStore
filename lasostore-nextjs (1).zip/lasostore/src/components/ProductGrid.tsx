"use client";
// El carrito solo guarda "que producto y cuantas unidades" en localStorage
// para que sobreviva un refresh; el precio, stock y total REALES se
// recalculan siempre en el servidor en /api/checkout antes de confirmar.
import { useState } from "react";

type Product = { id: string; name: string; price: number; old_price: number | null; stock: number; image_url: string | null; };

export default function ProductGrid({ products, categories }: { products: Product[]; categories: any[] }) {
  const [cart, setCart] = useState<{ product_id: string; quantity: number }[]>([]);

  function addToCart(id: string) {
    setCart((c) => {
      const found = c.find((i) => i.product_id === id);
      if (found) return c.map((i) => (i.product_id === id ? { ...i, quantity: i.quantity + 1 } : i));
      return [...c, { product_id: id, quantity: 1 }];
    });
  }

  async function checkout() {
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: cart })
    });
    const data = await res.json();
    if (!res.ok) { alert(data.error); return; }
    setCart([]);
    alert("Pedido creado: " + data.order_id);
  }

  return (
    <div style={{ padding: 20 }}>
      <div className="grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 18 }}>
        {products.map((p) => (
          <div key={p.id} className="pcard" style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 16, padding: 14 }}>
            <div>{p.name}</div>
            <div>S/ {p.price}{p.old_price ? <s style={{ marginLeft: 6, opacity: .6 }}>S/ {p.old_price}</s> : null}</div>
            <div>{p.stock > 0 ? "Disponible" : "Agotado"}</div>
            <button className="buy-btn" disabled={p.stock <= 0} onClick={() => addToCart(p.id)}>Añadir</button>
          </div>
        ))}
      </div>
      {cart.length > 0 && (
        <button className="buy-btn" style={{ marginTop: 20 }} onClick={checkout}>
          Confirmar pedido ({cart.reduce((a, i) => a + i.quantity, 0)} items)
        </button>
      )}
    </div>
  );
}
