// Server Component: los productos, categorias y banners salen de la base
// de datos (RLS solo deja ver los activos), no de un array hardcodeado.
import { createClient } from "@/lib/supabase/server";
import ProductGrid from "@/components/ProductGrid";

export default async function HomePage() {
  const supabase = createClient();
  const [{ data: products }, { data: categories }, { data: banners }] = await Promise.all([
    supabase.from("products").select("*").eq("active", true).order("created_at", { ascending: false }),
    supabase.from("categories").select("*").eq("active", true),
    supabase.from("banners").select("*").eq("active", true).order("position")
  ]);

  return (
    <main>
      <section style={{ padding: 20 }}>
        {banners?.[0] && <h1>{banners[0].title}</h1>}
      </section>
      <ProductGrid products={products ?? []} categories={categories ?? []} />
    </main>
  );
}
