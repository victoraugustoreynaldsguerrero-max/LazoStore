"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const supabase = createClient();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) { setError("Correo o contraseña incorrectos."); return; }
    router.push("/");
    router.refresh();
  }

  async function handleGoogle() {
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${location.origin}/auth/callback` }
    });
  }

  return (
    <div className="auth-card">
      <h2>Iniciar sesión</h2>
      <button className="btn-google" onClick={handleGoogle}>Continuar con Google</button>
      <div className="divider">o con correo electrónico</div>
      <form onSubmit={handleLogin}>
        <input type="email" placeholder="Correo" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Contraseña" value={password} onChange={(e) => setPassword(e.target.value)} required />
        {error && <p className="form-error">{error}</p>}
        <button className="buy-btn" disabled={loading}>{loading ? "Entrando..." : "Iniciar sesión"}</button>
      </form>
      <a href="/forgot-password">¿Olvidaste tu contraseña?</a>
      <a href="/register">Crear una cuenta</a>
    </div>
  );
}
