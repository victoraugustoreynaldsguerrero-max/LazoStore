"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function ForgotPasswordPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${location.origin}/auth/callback?next=/account/new-password`
    });
    setSent(true);
  }

  return (
    <div className="auth-card">
      <h2>Recuperar contraseña</h2>
      {sent ? (
        <p>Si el correo existe, te enviamos un enlace para restablecer tu contraseña.</p>
      ) : (
        <form onSubmit={handleReset}>
          <input type="email" placeholder="Tu correo" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <button className="buy-btn">Enviar enlace</button>
        </form>
      )}
    </div>
  );
}
