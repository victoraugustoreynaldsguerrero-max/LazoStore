import { createClient } from "@/lib/supabase/server";
import { updateOrderStatus } from "./actions";

const STATES = ["pending", "paid", "shipped", "completed", "cancelled"];

export default async function AdminOrders() {
  const supabase = createClient();
  const { data: orders } = await supabase
    .from("orders")
    .select("id, total, status, created_at, profiles(email)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h2>Pedidos</h2>
      <table>
        <thead><tr><th>Pedido</th><th>Cliente</th><th>Total</th><th>Estado</th><th>Fecha</th></tr></thead>
        <tbody>
          {(orders ?? []).map((o: any) => (
            <tr key={o.id}>
              <td>{o.id.slice(0, 8)}</td>
              <td>{o.profiles?.email}</td>
              <td>S/ {o.total}</td>
              <td>
                <form action={updateOrderStatus.bind(null, o.id, "")}>
                  <select name="status" defaultValue={o.status} onChange={(e) => updateOrderStatus(o.id, e.target.value)}>
                    {STATES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </form>
              </td>
              <td>{new Date(o.created_at).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
