"use server";
// Server Actions: corren en el servidor, usan el cliente autenticado por
// cookies (no la service key), asi que RLS + is_admin() son quienes
// realmente deciden si la operacion se permite, sin importar lo que
// mande el frontend.
import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function upsertProduct(formData: FormData) {
  const supabase = createClient();
  const id = formData.get("id") as string | null;
  const payload = {
    name: formData.get("name") as string,
    description: formData.get("description") as string,
    price: Number(formData.get("price")),
    old_price: formData.get("old_price") ? Number(formData.get("old_price")) : null,
    stock: Number(formData.get("stock")),
    category_id: (formData.get("category_id") as string) || null,
    image_url: (formData.get("image_url") as string) || null,
    active: formData.get("active") === "on"
  };

  const { error } = id
    ? await supabase.from("products").update(payload).eq("id", id)
    : await supabase.from("products").insert(payload);

  if (error) throw new Error(error.message);
  revalidatePath("/admin/products");
  revalidatePath("/");
}

export async function deleteProduct(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/products");
}

export async function uploadProductImage(file: File) {
  const supabase = createClient();
  const allowed = ["image/jpeg", "image/png", "image/webp"];
  if (!allowed.includes(file.type)) throw new Error("Formato no permitido");
  if (file.size > 4 * 1024 * 1024) throw new Error("Máximo 4MB");

  const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g, "")}`;
  const { data, error } = await supabase.storage.from("products").upload(safeName, file, { upsert: false });
  if (error) throw new Error(error.message);
  const { data: pub } = supabase.storage.from("products").getPublicUrl(data.path);
  return pub.publicUrl;
}
