import { createClient } from "@/lib/supabase/server";
import { upsertProduct, deleteProduct } from "./actions";

export default async function AdminProducts() {
  const supabase = createClient();
  const { data: products } = await supabase.from("products").select("*, categories(name)").order("created_at", { ascending: false });

  return (
    <div>
      <h2>Productos</h2>
      <form action={upsertProduct} style={{ marginBottom: 20, display: "grid", gap: 8, maxWidth: 420 }}>
        <input name="name" placeholder="Nombre" required />
        <input name="description" placeholder="Descripción" />
        <input name="price" type="number" step="0.01" placeholder="Precio" required />
        <input name="old_price" type="number" step="0.01" placeholder="Precio anterior" />
        <input name="stock" type="number" placeholder="Stock" required />
        <input name="image_url" placeholder="URL de imagen (o sube abajo)" />
        <label><input name="active" type="checkbox" defaultChecked /> Activo</label>
        <button className="buy-btn">Crear producto</button>
      </form>

      <table>
        <thead><tr><th>Imagen</th><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
          {(products ?? []).map((p: any) => (
            <tr key={p.id}>
              <td>{p.image_url ? <img src={p.image_url} width={40} /> : "—"}</td>
              <td>{p.name}</td>
              <td>{p.categories?.name ?? "—"}</td>
              <td>S/ {p.price}</td>
              <td>{p.stock}</td>
              <td>{p.active ? "Activo" : "Oculto"}</td>
              <td>
                <form action={deleteProduct.bind(null, p.id)} style={{ display: "inline" }}>
                  <button className="buy-btn" style={{ background: "var(--pink)" }}>Eliminar</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
