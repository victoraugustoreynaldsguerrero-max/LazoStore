import { createClient } from "@/lib/supabase/server";

export default async function AdminCustomers() {
  const supabase = createClient();
  const { data: customers } = await supabase.from("profiles").select("id, email, name, role, created_at").order("created_at", { ascending: false });
  return (
    <div>
      <h2>Clientes</h2>
      <table>
        <thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Desde</th></tr></thead>
        <tbody>
          {(customers ?? []).map((c: any) => (
            <tr key={c.id}><td>{c.name}</td><td>{c.email}</td><td>{c.role}</td><td>{new Date(c.created_at).toLocaleDateString()}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
