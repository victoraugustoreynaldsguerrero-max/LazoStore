"use server";
import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function upsertCategory(formData: FormData) {
  const supabase = createClient();
  const id = formData.get("id") as string | null;
  const payload = {
    name: formData.get("name") as string,
    icon: formData.get("icon") as string,
    image_url: (formData.get("image_url") as string) || null,
    active: formData.get("active") === "on"
  };
  const { error } = id
    ? await supabase.from("categories").update(payload).eq("id", id)
    : await supabase.from("categories").insert(payload);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/categories");
}

export async function deleteCategory(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("categories").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/categories");
}
