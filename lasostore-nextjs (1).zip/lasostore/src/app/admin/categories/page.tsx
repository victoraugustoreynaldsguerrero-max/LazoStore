import { createClient } from "@/lib/supabase/server";
import { upsertCategory, deleteCategory } from "./actions";

export default async function AdminCategories() {
  const supabase = createClient();
  const { data: categories } = await supabase.from("categories").select("*");
  return (
    <div>
      <h2>Categorías</h2>
      <form action={upsertCategory} style={{ display: "grid", gap: 8, maxWidth: 380, marginBottom: 20 }}>
        <input name="name" placeholder="Nombre" required />
        <input name="icon" placeholder="Icono (emoji)" />
        <input name="image_url" placeholder="URL imagen" />
        <label><input name="active" type="checkbox" defaultChecked /> Activa</label>
        <button className="buy-btn">Crear categoría</button>
      </form>
      <table>
        <thead><tr><th>Nombre</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
          {(categories ?? []).map((c: any) => (
            <tr key={c.id}>
              <td>{c.icon} {c.name}</td>
              <td>{c.active ? "Activa" : "Oculta"}</td>
              <td><form action={deleteCategory.bind(null, c.id)}><button className="buy-btn" style={{ background: "var(--pink)" }}>Eliminar</button></form></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
