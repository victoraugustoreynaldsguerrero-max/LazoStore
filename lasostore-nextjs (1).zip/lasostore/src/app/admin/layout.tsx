// Segunda capa de defensa ademas del middleware: si alguien llegara aqui
// sin ser admin, esto tambien corta el paso (defensa en profundidad).
import { redirect } from "next/navigation";
import { getProfile } from "@/lib/supabase/server";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const profile = await getProfile();
  if (!profile || profile.role !== "admin") redirect("/");

  return (
    <div className="admin-shell">
      <nav className="admin-nav">
        <a href="/admin">Dashboard</a>
        <a href="/admin/products">Productos</a>
        <a href="/admin/categories">Categorías</a>
        <a href="/admin/banners">Banners</a>
        <a href="/admin/orders">Pedidos</a>
        <a href="/admin/customers">Clientes</a>
      </nav>
      <div className="admin-content">{children}</div>
    </div>
  );
}
