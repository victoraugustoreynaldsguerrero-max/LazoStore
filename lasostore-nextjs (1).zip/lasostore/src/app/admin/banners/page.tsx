import { createClient } from "@/lib/supabase/server";
import { upsertBanner, deleteBanner } from "./actions";

export default async function AdminBanners() {
  const supabase = createClient();
  const { data: banners } = await supabase.from("banners").select("*").order("position");
  return (
    <div>
      <h2>Banners</h2>
      <form action={upsertBanner} style={{ display: "grid", gap: 8, maxWidth: 420, marginBottom: 20 }}>
        <input name="title" placeholder="Título" required />
        <input name="description" placeholder="Descripción" />
        <input name="image_url" placeholder="URL imagen" />
        <input name="button_text" placeholder="Texto del botón" />
        <input name="button_url" placeholder="URL del botón" />
        <input name="position" type="number" placeholder="Posición" />
        <label><input name="active" type="checkbox" defaultChecked /> Activo</label>
        <button className="buy-btn">Crear banner</button>
      </form>
      <table>
        <thead><tr><th>Título</th><th>Posición</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
          {(banners ?? []).map((b: any) => (
            <tr key={b.id}>
              <td>{b.title}</td><td>{b.position}</td><td>{b.active ? "Activo" : "Oculto"}</td>
              <td><form action={deleteBanner.bind(null, b.id)}><button className="buy-btn" style={{ background: "var(--pink)" }}>Eliminar</button></form></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
