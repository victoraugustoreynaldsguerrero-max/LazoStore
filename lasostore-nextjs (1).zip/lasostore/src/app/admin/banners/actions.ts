"use server";
import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function upsertBanner(formData: FormData) {
  const supabase = createClient();
  const id = formData.get("id") as string | null;
  const payload = {
    title: formData.get("title") as string,
    description: formData.get("description") as string,
    image_url: (formData.get("image_url") as string) || null,
    button_text: formData.get("button_text") as string,
    button_url: formData.get("button_url") as string,
    position: Number(formData.get("position") || 0),
    active: formData.get("active") === "on"
  };
  const { error } = id
    ? await supabase.from("banners").update(payload).eq("id", id)
    : await supabase.from("banners").insert(payload);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/banners");
  revalidatePath("/");
}

export async function deleteBanner(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("banners").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/banners");
}
