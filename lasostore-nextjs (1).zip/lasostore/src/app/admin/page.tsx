import { createClient } from "@/lib/supabase/server";

export default async function AdminDashboard() {
  const supabase = createClient();
  const [{ count: products }, { count: outOfStock }, { count: orders }, { count: customers }, { data: sales }] = await Promise.all([
    supabase.from("products").select("*", { count: "exact", head: true }),
    supabase.from("products").select("*", { count: "exact", head: true }).eq("stock", 0),
    supabase.from("orders").select("*", { count: "exact", head: true }),
    supabase.from("profiles").select("*", { count: "exact", head: true }).eq("role", "customer"),
    supabase.from("orders").select("total").eq("status", "paid")
  ]);
  const totalSales = (sales ?? []).reduce((a, o) => a + Number(o.total), 0);

  return (
    <div>
      <h2>Dashboard</h2>
      <div className="stat-grid">
        <div className="stat-card"><b>{products ?? 0}</b>Productos</div>
        <div className="stat-card"><b>{outOfStock ?? 0}</b>Sin stock</div>
        <div className="stat-card"><b>{orders ?? 0}</b>Pedidos</div>
        <div className="stat-card"><b>S/ {totalSales}</b>Ventas</div>
        <div className="stat-card"><b>{customers ?? 0}</b>Clientes</div>
      </div>
    </div>
  );
}
