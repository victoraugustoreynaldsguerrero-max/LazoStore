import { redirect } from "next/navigation";
import { createClient, getProfile } from "@/lib/supabase/server";

export default async function AccountPage() {
  const supabase = createClient();
  const profile = await getProfile();
  if (!profile) redirect("/login?next=/account");

  const { data: orders } = await supabase
    .from("orders")
    .select("id, total, status, created_at")
    .order("created_at", { ascending: false });

  return (
    <main style={{ padding: 24, maxWidth: 700, margin: "0 auto" }}>
      <h2>Mi cuenta</h2>
      <p>Nombre: {profile.name}</p>
      <p>Correo: {profile.email}</p>
      <form action="/auth/callback" method="post"></form>
      <h3 style={{ marginTop: 20 }}>Mis pedidos</h3>
      <table>
        <thead><tr><th>Pedido</th><th>Total</th><th>Estado</th><th>Fecha</th></tr></thead>
        <tbody>
          {(orders ?? []).map((o) => (
            <tr key={o.id}><td>{o.id.slice(0, 8)}</td><td>S/ {o.total}</td><td>{o.status}</td><td>{new Date(o.created_at).toLocaleDateString()}</td></tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
