// Route Handler: el UNICO lugar donde se crea un pedido.
// Nunca confia en el precio que manda el navegador: llama a create_order(),
// que relee precio y stock reales desde la base de datos.
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "No autenticado" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const items = body?.items; // [{ product_id, quantity }]
  if (!Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "Carrito vacio" }, { status: 400 });
  }
  const valid = items.every(
    (i) => typeof i.product_id === "string" && Number.isInteger(i.quantity) && i.quantity > 0
  );
  if (!valid) {
    return NextResponse.json({ error: "Items invalidos" }, { status: 400 });
  }

  const { data, error } = await supabase.rpc("create_order", {
    p_user_id: user.id,
    p_items: items
  });

  if (error) {
    // No exponemos el detalle interno del error al cliente.
    console.error("checkout error", error.message);
    return NextResponse.json({ error: "No se pudo completar el pedido" }, { status: 400 });
  }

  return NextResponse.json({ order_id: data });
}
