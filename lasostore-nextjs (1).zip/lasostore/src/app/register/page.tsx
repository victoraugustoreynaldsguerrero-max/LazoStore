"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function RegisterPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: name }, emailRedirectTo: `${location.origin}/auth/callback` }
    });
    if (error) { setError(error.message); return; }
    setSent(true);
  }

  if (sent) {
    return <div className="auth-card"><h2>Revisa tu correo</h2><p>Te enviamos un enlace para verificar tu cuenta.</p></div>;
  }

  return (
    <div className="auth-card">
      <h2>Crear cuenta</h2>
      <form onSubmit={handleRegister}>
        <input placeholder="Nombre" value={name} onChange={(e) => setName(e.target.value)} required />
        <input type="email" placeholder="Correo" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Contraseña (mín. 8 caracteres)" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
        {error && <p className="form-error">{error}</p>}
        <button className="buy-btn">Registrarme</button>
      </form>
    </div>
  );
}
